/*
 * Author:           
 * Student Number:   
 * Lab Section:      
 * Date:             $time$
 *           
 * Purpose:  
 *
 */
#define _CRT_SECURE_NO_WARNINGS

int main(void)
{

	/* insert your code here */

	return 0;
}